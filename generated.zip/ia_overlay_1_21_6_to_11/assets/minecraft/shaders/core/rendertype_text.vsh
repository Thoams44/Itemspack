#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_a58d68e2(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_b54dcb06() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_2780b39a(inout vec4 vertex) {
    f_a58d68e2(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_b54dcb06();
    }
    finalize();
}



void f_7d3c8e2b() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_1609b199() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_5e02af35(inout vec4 vertex) {
    f_a58d68e2(vertex);
    f_7d3c8e2b();
    finalize();
}

void f_3906d51f(inout vec4 vertex) {
    f_a58d68e2(vertex);
    f_b54dcb06();
    f_1609b199();
    finalize();
}

void f_32cc3dbc(inout vec4 vertex) {
    f_a58d68e2(vertex);
    f_1609b199();
    f_7d3c8e2b();
    finalize();
}

void f_24a832d3(inout vec4 vertex) {
    f_b54dcb06();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a58d68e2(vertex);
    finalize();
}

void f_f873ae13(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7d3c8e2b();
    f_a58d68e2(vertex);
    finalize();
}

void f_e801ff22(inout vec4 vertex, float speed) {
    f_a58d68e2(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_78c15488(inout vec4 vertex) {
    f_a58d68e2(vertex);
    f_b54dcb06();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_2780b39a(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_b54dcb06();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_a58d68e2(vertex);
            f_b54dcb06();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_3906d51f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_3906d51f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_24a832d3(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_24a832d3(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_e801ff22(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_78c15488(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_5e02af35(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_3906d51f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_32cc3dbc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_24a832d3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_f873ae13(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_e801ff22(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_5e02af35(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_3906d51f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_32cc3dbc(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_24a832d3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_f873ae13(vertex);
        return;
    }
    

    
    f_a58d68e2(vertex);
    f_b54dcb06();
    finalize();
}