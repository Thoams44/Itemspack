#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_22fa202b(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_987df87d() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_b9ec478f(inout vec4 vertex) {
    f_22fa202b(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_987df87d();
    }
    finalize();
}



void f_a63f2ff0() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_21b99e60() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_93fb8af3(inout vec4 vertex) {
    f_22fa202b(vertex);
    f_a63f2ff0();
    finalize();
}

void f_10802feb(inout vec4 vertex) {
    f_22fa202b(vertex);
    f_987df87d();
    f_21b99e60();
    finalize();
}

void f_21f62316(inout vec4 vertex) {
    f_22fa202b(vertex);
    f_21b99e60();
    f_a63f2ff0();
    finalize();
}

void f_36f3cd7e(inout vec4 vertex) {
    f_987df87d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_22fa202b(vertex);
    finalize();
}

void f_d570f086(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a63f2ff0();
    f_22fa202b(vertex);
    finalize();
}

void f_611b0f46(inout vec4 vertex, float speed) {
    f_22fa202b(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_0e518637(inout vec4 vertex) {
    f_22fa202b(vertex);
    f_987df87d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_b9ec478f(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_987df87d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_22fa202b(vertex);
            f_987df87d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_10802feb(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_10802feb(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_36f3cd7e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_36f3cd7e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_611b0f46(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_0e518637(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_93fb8af3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_10802feb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_21f62316(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_36f3cd7e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_d570f086(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_611b0f46(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_93fb8af3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_10802feb(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_21f62316(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_36f3cd7e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_d570f086(vertex);
        return;
    }
    

    
    f_22fa202b(vertex);
    f_987df87d();
    finalize();
}