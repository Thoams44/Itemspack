#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>






#define hue(v) ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.))

#define finalize() { texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0.) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

vec4 lightmapped_color(vec4 color) {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    return color*sample_lightmap(Sampler2, UV2);
#else
    return color;
#endif
}

void f_ac8db544(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_332a84c7() {
    vertexColor=lightmapped_color(Color);
}


void f_5126b4a3(inout vec4 vertex) {
    f_ac8db544(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_332a84c7();
    }
    finalize();
}



void f_236e9a9e() {
    vertexColor=lightmapped_color(hue(gl_Position.x+safeGameTime()*1000.));
}

void f_e83ec1eb() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6.)) / 150.;
}

void f_ade26055(inout vec4 vertex) {
    f_ac8db544(vertex);
    f_236e9a9e();
    finalize();
}

void f_ae1bcc8b(inout vec4 vertex) {
    f_ac8db544(vertex);
    f_332a84c7();
    f_e83ec1eb();
    finalize();
}

void f_cff5365f(inout vec4 vertex) {
    f_ac8db544(vertex);
    f_e83ec1eb();
    f_236e9a9e();
    finalize();
}

void f_5bd84057(inout vec4 vertex) {
    f_332a84c7();
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_ac8db544(vertex);
    finalize();
}

void f_dab5dc39(inout vec4 vertex) {
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_ac8db544(vertex);
    f_236e9a9e();
    finalize();
}

void f_ee7d6f19(inout vec4 vertex, float speed) {
    f_ac8db544(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=lightmapped_color(Color*blink);
    finalize();
}



void f_af5eb46c(inout vec4 vertex) {
    f_ac8db544(vertex);
    f_332a84c7();
    vertexColor=vec4(1., 1., 1., vertexColor.a);
    finalize();
}


void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
#endif
    f_332a84c7();

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255.+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85)) {
        f_5126b4a3(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9)) {
            gl_Position=vec4(2., 2., 2., 1.);
            f_332a84c7();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            f_ac8db544(vertex);
            f_332a84c7();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_ae1bcc8b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            f_ae1bcc8b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_5bd84057(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_5bd84057(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_ee7d6f19(vertex, .5);
            return;
        }

        
        
    }

    
    
    if(iColor==ivec3(78, 92, 36)) {
        f_af5eb46c(vertex);
        return;
    }
    

    
    
    if(iColor==ivec3(230, 255, 254)) {
        f_ade26055(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250)) {
        f_ae1bcc8b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254)) {
        f_cff5365f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250)) {
        f_5bd84057(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254)) {
        f_dab5dc39(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250)) {
        f_ee7d6f19(vertex, .5);
        return;
    }

    
    

    
    
    if(iColor==ivec3(255, 255, 254)) {
        f_ade26055(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 253)) {
        f_ae1bcc8b(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 252)) {
        f_cff5365f(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 251)) {
        f_5bd84057(vertex);
        return;
    }

    if(iColor==ivec3(255, 254, 254)) {
        f_dab5dc39(vertex);
        return;
    }
    

    f_ac8db544(vertex);
    f_332a84c7();
    finalize();
}