#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>






#define hue(v) ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.))

#define finalize() { texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0.) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

vec4 lightmapped_color(vec4 color) {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    return color*sample_lightmap(Sampler2, UV2);
#else
    return color;
#endif
}

void f_a6df3e42(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_1717faf0() {
    vertexColor=lightmapped_color(Color);
}


void f_2b5e2e0e(inout vec4 vertex) {
    f_a6df3e42(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_1717faf0();
    }
    finalize();
}



void f_7c87dcb1() {
    vertexColor=lightmapped_color(hue(gl_Position.x+safeGameTime()*1000.));
}

void f_fd4e0c19() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6.)) / 150.;
}

void f_7b5092e7(inout vec4 vertex) {
    f_a6df3e42(vertex);
    f_7c87dcb1();
    finalize();
}

void f_aefea08a(inout vec4 vertex) {
    f_a6df3e42(vertex);
    f_1717faf0();
    f_fd4e0c19();
    finalize();
}

void f_bcef6a8c(inout vec4 vertex) {
    f_a6df3e42(vertex);
    f_fd4e0c19();
    f_7c87dcb1();
    finalize();
}

void f_af11d288(inout vec4 vertex) {
    f_1717faf0();
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_a6df3e42(vertex);
    finalize();
}

void f_a0ee082e(inout vec4 vertex) {
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_a6df3e42(vertex);
    f_7c87dcb1();
    finalize();
}

void f_4cfcb523(inout vec4 vertex, float speed) {
    f_a6df3e42(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=lightmapped_color(Color*blink);
    finalize();
}



void f_66f8db68(inout vec4 vertex) {
    f_a6df3e42(vertex);
    f_1717faf0();
    vertexColor=vec4(1., 1., 1., vertexColor.a);
    finalize();
}


void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
#endif
    f_1717faf0();

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255.+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85)) {
        f_2b5e2e0e(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9)) {
            gl_Position=vec4(2., 2., 2., 1.);
            f_1717faf0();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            f_a6df3e42(vertex);
            f_1717faf0();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_aefea08a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            f_aefea08a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_af11d288(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_af11d288(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_4cfcb523(vertex, .5);
            return;
        }

        
        
    }

    
    
    if(iColor==ivec3(78, 92, 36)) {
        f_66f8db68(vertex);
        return;
    }
    

    
    
    if(iColor==ivec3(230, 255, 254)) {
        f_7b5092e7(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250)) {
        f_aefea08a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254)) {
        f_bcef6a8c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250)) {
        f_af11d288(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254)) {
        f_a0ee082e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250)) {
        f_4cfcb523(vertex, .5);
        return;
    }

    
    

    
    
    if(iColor==ivec3(255, 255, 254)) {
        f_7b5092e7(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 253)) {
        f_aefea08a(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 252)) {
        f_bcef6a8c(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 251)) {
        f_af11d288(vertex);
        return;
    }

    if(iColor==ivec3(255, 254, 254)) {
        f_a0ee082e(vertex);
        return;
    }
    

    f_a6df3e42(vertex);
    f_1717faf0();
    finalize();
}