#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_647e8c37(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_10ac3d06() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_7f765561(inout vec4 vertex) {
    f_647e8c37(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_10ac3d06();
    }
        finalize();
}



void f_f273617d() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_7fac3e6f() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_8258b881(inout vec4 vertex) {
    f_647e8c37(vertex);
    f_f273617d();
    finalize();
}

void f_8967071d(inout vec4 vertex) {
    f_647e8c37(vertex);
    f_10ac3d06();
    f_7fac3e6f();
    finalize();
}

void f_0badb0c1(inout vec4 vertex) {
    f_647e8c37(vertex);
    f_7fac3e6f();
    f_f273617d();
    finalize();
}

void f_529c3ffb(inout vec4 vertex) {
    f_10ac3d06();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_647e8c37(vertex);
    finalize();
}

void f_a0346e01(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_f273617d();
    f_647e8c37(vertex);
    finalize();
}

void f_9b3ab9e3(inout vec4 vertex, float speed) {
    f_647e8c37(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_336dcf9f(inout vec4 vertex) {
    f_647e8c37(vertex);
    f_10ac3d06();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_7f765561(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_10ac3d06();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_647e8c37(vertex);
            f_10ac3d06();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_8967071d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_8967071d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_529c3ffb(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_529c3ffb(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_9b3ab9e3(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_336dcf9f(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_8258b881(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_8967071d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_0badb0c1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_529c3ffb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_a0346e01(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_9b3ab9e3(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_8258b881(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_8967071d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_0badb0c1(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_529c3ffb(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_a0346e01(vertex);
        return;
    }
    

    
    f_647e8c37(vertex);
    f_10ac3d06();
    finalize();
}